﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Open.Data;

namespace Open.Tests.Data
{
    [TestClass]
    public class DummyTests : ClassTests<Dummy>
    {
    }
}