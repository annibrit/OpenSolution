﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Open.Archetypes.OrderClasses;

namespace Open.Tests.Archetypes.OrderClasses
{
    [TestClass]
    public partial class SalesTaxPolicyTests : CommonTests<SalesTaxPolicy>
    {
        protected override SalesTaxPolicy GetRandomObj()
        {
            return SalesTaxPolicy.Random();
        }
        [TestInitialize]
        public override void TestInitialize()
        {
            base.TestInitialize();
        }
        [TestCleanup]
        public override void TestCleanup()
        {
            base.TestCleanup();
        }
        [TestMethod]
        public void TaxTypeTest()
        {
            TestProperty(() => Obj.TaxType, x => Obj.TaxType = x);
        }

        [TestMethod]
        public void RateTest()
        {
            TestProperty(() => Obj.Rate, x => Obj.Rate = x);
        }
    }
}