﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Open.Archetypes.OrderClasses;

namespace Open.Tests.Archetypes.OrderClasses
{
    [TestClass]
    public class DiscountTests : CommonTests<Discount>
    {
        protected override Discount GetRandomObj()
        {
            return Discount.Random();
        }
        [TestInitialize]
        public override void TestInitialize()
        {
            base.TestInitialize();
        }
        [TestCleanup]
        public override void TestCleanup()
        {
            base.TestCleanup();
        }
        [TestMethod]
        public void ReasonTest()
        {
            TestProperty(() => Obj.Reason, x => Obj.Reason = x);
        }
    }
}