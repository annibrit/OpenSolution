﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Open.Logic;

namespace Open.Tests.Logic
{
    [TestClass]
    public class DummyTests : ClassTests<Dummy>
    {
    }
}