﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.QuantityClasses
{
    public class Quantity : Archetype
    {
    }
}