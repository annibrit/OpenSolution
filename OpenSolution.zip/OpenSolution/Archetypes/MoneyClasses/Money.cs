﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.MoneyClasses
{
    public class Money : Archetype
    {
    }
}