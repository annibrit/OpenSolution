﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.RuleClasses
{
    public class Rule : UniqueEntity
    {
    }
}