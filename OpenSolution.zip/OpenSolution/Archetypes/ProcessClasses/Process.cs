﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.ProcessClasses
{
    public class Process : Archetype
    {
    }
}