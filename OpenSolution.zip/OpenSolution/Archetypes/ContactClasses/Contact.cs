﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.ContactClasses
{
    public class Contact : Archetype
    {
    }
}