﻿namespace Open.Archetypes.OrderClasses
{
    public enum OrderStatus
    {
        Initializing = 0,
        Open = 1,
        Close = 2,
        Cancelled = 3
    }
}