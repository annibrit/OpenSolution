﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.OrderClasses
{
    public class UniqueIdentifier : UniqueEntity
    {
        //TODO kas see klass on vajalik?
    }
}