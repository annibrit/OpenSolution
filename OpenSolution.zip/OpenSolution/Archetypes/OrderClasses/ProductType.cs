﻿namespace Open.Archetypes.OrderClasses
{
    public class ProductType
    {
    }
}