﻿namespace Open.Archetypes.ProductClasses
{
    public class CompletedService : Service
    {
    }
}