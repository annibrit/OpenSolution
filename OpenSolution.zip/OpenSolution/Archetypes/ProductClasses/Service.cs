﻿namespace Open.Archetypes.ProductClasses
{
    public class Service : Product
    {
    }
}