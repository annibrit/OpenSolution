﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.ProductClasses
{
    public class Product : Archetype
    {
    }
}