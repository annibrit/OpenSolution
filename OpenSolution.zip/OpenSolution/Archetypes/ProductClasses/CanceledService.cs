﻿namespace Open.Archetypes.ProductClasses
{
    public class CanceledService : Service
    {               
    }
}