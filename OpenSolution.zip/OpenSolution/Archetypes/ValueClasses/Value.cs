﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.ValueClasses
{
    public class Value : Archetype
    {
    }
}