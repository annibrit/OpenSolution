﻿namespace Open.Archetypes.BaseClasses
{
    public class Attributes : Archetypes<Attribute>
    {
        public static Attributes Instance { get; } = new Attributes();
    }
}