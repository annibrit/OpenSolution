﻿namespace Open.Archetypes.BaseClasses
{
    public abstract class AttributedEntity : TemporalEntity
    {
        public abstract Attributes Attributes { get; }
    }
}