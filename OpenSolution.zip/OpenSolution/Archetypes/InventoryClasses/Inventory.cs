﻿using Open.Archetypes.BaseClasses;

namespace Open.Archetypes.InventoryClasses
{
    public class Inventory : Archetype
    {
    }
}