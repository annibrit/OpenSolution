﻿namespace Open.Data
{
    public class Dummy
    {
    }
}