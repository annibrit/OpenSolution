﻿namespace Open.Aids
{
    public class Char
    {
        public static char Comma => ',';
        public static char Eol => '\n';
        public static char Tab => '\t';
        public static bool IsDot(char c) => c.Equals('.');
    }
}