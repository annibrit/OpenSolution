﻿namespace Open.Aids
{
    public class Utils
    {
        public static bool IsNull(object o)
        {
            return ReferenceEquals(null, o);
        }
    }
}